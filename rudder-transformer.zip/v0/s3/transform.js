function process(events) {
  return events;
}

exports.process = process;
