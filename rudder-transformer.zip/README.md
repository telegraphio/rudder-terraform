# rudder-transformer

Transformer is a service which transforms Rudder events to destination specific singular events. This is released under
under [Apache License 2.0](https://www.apache.org/licenses/LICENSE-2.0)


## Setup

1. Clone the repository
2. Run `npm install`

## Running on your machine

```npm start```

## Running with docker

```docker-compose up```
