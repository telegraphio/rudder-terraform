const EventType = {
  PAGE: "page",
  SCREEN: "screen",
  TRACK: "track",
  IDENTIFY: "identify"
};

module.exports = {
  EventType
};
